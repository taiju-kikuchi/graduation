package com.ashomok.tesseractsample;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.FileDescriptor;
import java.io.IOException;

public class MainActivity extends Activity implements ActivityCompat.OnRequestPermissionsResultCallback  {
    private static final String DATA_PATH = Environment.getExternalStorageDirectory().toString() + "/TesseractSample/";
    private static final int REQUEST_GALLERY = 10001;
    private static final String lang = "jpn";

    Bitmap bitmap;
    TessBaseAPI tessBaseApi;

    ImageView imageView;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView)findViewById(R.id.imageview);
        textView = (TextView) findViewById(R.id.textResult);

        Button captureImg = (Button) findViewById(R.id.action_btn);
        if (captureImg != null) {
            captureImg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    galleySeach();
                }
            });
        }
    }

    private void galleySeach() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri uri;
        if (requestCode == REQUEST_GALLERY && resultCode == RESULT_OK) {
            uri = data.getData();
            try {
                //Bitmapに画像を持ってくる
                bitmap = getBitmapFromUri(uri);
                imageView.setImageBitmap(bitmap);
                doOCR();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Bitmap getBitmapFromUri(Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptor =
                getContentResolver().openFileDescriptor(uri, "r");
        FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
        Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);
        parcelFileDescriptor.close();
        return image;
    }


    private String doOCR() {
        try {
            tessBaseApi = new TessBaseAPI();
        } catch (Exception e) {
            if (tessBaseApi == null) {
            }
        }

        tessBaseApi.init(DATA_PATH, lang);

        tessBaseApi.setImage(bitmap);

        String extractedText = "empty result";
        try {
            extractedText = tessBaseApi.getUTF8Text();
            textView.setText(extractedText);
        } catch (Exception e) {
        }
        tessBaseApi.end();
        return extractedText;
    }
}


